create table CustomerAcc(Account_ID NUMBER(10) , customer_name VARCHAR2(50), Email VARCHAR2(30), Address VARCHAR2(100), Pancard VARCHAR2(15), 
constraint pk_Account_ID primary key(Account_ID ));


create table AccountMaster
(Account_ID NUMBER(10),
 Account_Type VARCHAR2(25), 
Account_Balance NUMBER(15),
Open_Date date, constraint pk1_Account_ID primary key(Account_ID ),
constraint fk_accountId foreign key(account_id) references CustomerAcc(Account_ID));

create table User_Table(
Account_ID NUMBER(6),
user_id NUMBER(6),
loginpassword VARCHAR2(15),
secret_question VARCHAR2(50),
Transaction_password VARCHAR2(15),
lock_status VARCHAR2(1),
constraint pk_user_id primary key(user_id),
constraint unique_account_id  unique(account_id),
constraint fk_ut_account_id foreign key(account_id) references customeracc(account_id));

insert into CustomerAcc values (1000,'sasi','sasi@gmail.com','Dosapadu','PA1234');
insert into CustomerAcc values (1001,'sasi','sasi@gmail.com','Dosapadu','PA1234');
insert into CustomerAcc values (1002,'kiran','kiran@gmail.com','Dosapadu','PA1235');
insert into CustomerAcc values (1003,'kiran','kiran@gmail.com','Dosapadu','PA1235');
insert into CustomerAcc values (1004,'kiran1','kiran@gmail.com','Dosapadu1','PA135');

insert into user_table values(1000,5000,'sasi#123','Hyderabad','sasi@123','u');
insert into user_table values(1001,5001,'Kiran#123','snoopy','kiran@123','u');
insert into user_table values(1002,5002,'sajja#123','pizza','sajja@123','u');
insert into user_table values(1003,5003,'manu#123','chess','manu@123','u');


create table PayeeTable(Account_Id NUMBER ,Payee_Account_Id NUMBER, Nickname VARCHAR2(40),constraint pk_nickname primary key(nickname), 
constraint fk_pt_account_id foreign key(account_id) references customeracc(account_id));

insert into PayeeTable values(1000,1002,'kiran');
insert into PayeeTable values(1000,1001,'sasi');
insert into PayeeTable values(1001,1002,'sajja');

insert into AccountMaster values(1000,'savings',50000,'12-DEC-2017');
insert into AccountMaster values(1001,'savings',70000,'13-DEC-2017');
insert into AccountMaster values(1002,'current',90000,'14-DEC-2017');
insert into AccountMaster values(1003,'current',100000,'19-DEC-2017');


create table Fund_Transfer(FundTransfer_ID NUMBER ,Account_ID NUMBER(10) ,Payee_Account_ID NUMBER(10), Date_Of_Transfer DATE, Transfer_Amount NUMBER(15),
constraint pk_fundtransfer_id primary key(fundtransfer_id));

create sequence Fund_Transfer_seq start with 4000 increment by 1 nocache;

create table Transactions(Transaction_ID NUMBER,Tran_description VARCHAR2(100), DateofTransaction DATE , TransactionType VARCHAR2(1) ,TranAmount NUMBER(15)
,Account_id NUMBER(10),constraint pk_transaction_id primary key(transaction_id), constraint fk_tr_account_id  foreign key(account_id) references
CustomerAcc(Account_ID));

create sequence Transactions_seq start with 9000 increment by 1 nocache;


 select * from(select * from transactions where account_id=1001  order by dateoftransaction desc) where rownum<=3;
package com.cg.obs.bean;

public class PayeeDTO {
	private int account_id;
	private int payeeAccount_id;
	private String nick_name;
	
	
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
	public int getPayeeAccount_id() {
		return payeeAccount_id;
	}
	public void setPayeeAccount_id(int payeeAccount_id) {
		this.payeeAccount_id = payeeAccount_id;
	}
	public String getNick_name() {
		return nick_name;
	}
	public void setNick_name(String nick_name) {
		this.nick_name = nick_name;
	}
	
	
	@Override
	public String toString() {
		return "PayeeDTO [account_id=" + account_id + ", payeeAccount_id="
				+ payeeAccount_id + ", nick_name=" + nick_name + "]";
	}
	

	
	
}

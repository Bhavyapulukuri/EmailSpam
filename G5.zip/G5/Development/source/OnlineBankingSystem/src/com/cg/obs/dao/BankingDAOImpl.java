	package com.cg.obs.dao;
	
	import java.sql.Connection;
	import java.sql.Date;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
	import java.util.ArrayList;
	import java.util.List;
	
	import com.cg.obs.bean.CustomerDTO;
	import com.cg.obs.bean.FundTransferDTO;
	import com.cg.obs.bean.PayeeDTO;
	import com.cg.obs.bean.TransactionDTO;
	import com.cg.obs.bean.UserTableDTO;
	import com.cg.obs.exception.BankingException;
	import com.cg.obs.util.DbUtil;
	
	public class BankingDAOImpl implements BankingDAO {
	
		/*********************************************************************
		* Module Name : getUserDetails(Integer userId)
		* Input Parameters : userId
		* Return Type : UserTableDTO
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To retrieve user details
		*********************************************************************/
		@Override
		public UserTableDTO getUserDetails(Integer userId) throws BankingException {
			
			Connection con;
			PreparedStatement pst = null;
			ResultSet rs = null;
			UserTableDTO userObject = new UserTableDTO();
			
			con = DbUtil.getConnection();
			
			try {
				pst = con.prepareStatement("SELECT * FROM User_Table where user_id=?");
				
				pst.setInt(1, userId);
				
				rs  = pst.executeQuery();
				rs.next();
				userObject.setAccount_id(rs.getInt(1));
				userObject.setUser_id(rs.getInt(2));
				userObject.setLogin_password(rs.getString(3));
				userObject.setSecret_question(rs.getString(4));
				userObject.setTransaction_password(rs.getString(5));
				userObject.setLock_status(rs.getString(6));
				
				return userObject;
				
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}finally{
				try {
					con.close();
					pst.close();
					rs.close();
				} catch (SQLException e) {
					throw new BankingException(e.getMessage());
				}
		
			}
	
		}
		/*********************************************************************
		* Module Name : getPayeeDetails(int account_id)
		* Input Parameters : account_id
		* Return Type : List<PayeeDTO>
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To retrieve payee details
		*********************************************************************/
		@Override
		public List<PayeeDTO> getPayeeDetails(int account_id) throws BankingException {
			
			Connection con;
			PreparedStatement pst = null;
			ResultSet rs = null;
			List<PayeeDTO> payeeList= new ArrayList<PayeeDTO>();
			con = DbUtil.getConnection();
			
			try {
				pst = con.prepareStatement("SELECT * FROM PayeeTable where account_id=?");
				pst.setInt(1, account_id);
				rs = pst.executeQuery();
				
				while(rs.next()){
				
				PayeeDTO payeeObject = new PayeeDTO();
					
				payeeObject.setAccount_id(rs.getInt(1));
				payeeObject.setPayeeAccount_id(rs.getInt(2));
				payeeObject.setNick_name(rs.getString(3));
				
				payeeList.add(payeeObject);
				
				}
				return payeeList;
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					throw new BankingException(e.getMessage());
				}
			}
			
		}
		/*********************************************************************
		* Module Name : getAccountDetailsByUserId(int user_id)
		* Input Parameters : user_id
		* Return Type : List<Integer>
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To retrieve Account details
		*********************************************************************/
		@Override
		public List<Integer> getAccountDetailsByUserId(int user_id)
				throws BankingException {
			Connection con;
			PreparedStatement pst = null;
			ResultSet rs = null;
			List<Integer> acclist= new ArrayList<Integer>();
	
			con = DbUtil.getConnection();
			
			try {
				pst = con.prepareStatement("SELECT account_id FROM user_table where user_id=?");
				pst.setInt(1, user_id);
				rs = pst.executeQuery();
				rs.next();
				int acc=rs.getInt(1);
				
				pst = con.prepareStatement("SELECT Pancard FROM CustomerAcc where account_id=?");
				pst.setInt(1, acc);
				rs = pst.executeQuery();
				rs.next();
				String str=rs.getString("Pancard");
				pst = con.prepareStatement("SELECT account_id FROM CustomerAcc where pancard=?");
				pst.setString(1, str);
				rs = pst.executeQuery();
				
				while(rs.next()){
					acclist.add(rs.getInt(1));
				}
					return acclist;
			
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					throw new BankingException(e.getMessage());
				}
			}
		}
		/*********************************************************************
		* Module Name : insertPayeeDetails(PayeeDTO payee)
		* Input Parameters : payee
		* Return Type : int
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To insert payee details into database
		*********************************************************************/
		@Override
		public int insertPayeeDetails(PayeeDTO payee) throws BankingException {
			
			Connection con;
			PreparedStatement pst = null;
			ResultSet rs = null;
			con = DbUtil.getConnection();
			
			try {
				pst=con.prepareStatement("INSERT INTO PayeeTable VALUES(?,?,?)");
				pst.setInt(1, payee.getAccount_id());
				pst.setInt(2, payee.getPayeeAccount_id());
				pst.setString(3, payee.getNick_name());
				return pst.executeUpdate();
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					throw new BankingException(e.getMessage());
				}
			}
		}
		/*********************************************************************
		* Module Name : validPayeeAccountId(int payeeaccid)
		* Input Parameters : payeeaccid
		* Return Type : int
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To check whether payyee id is valid or not
		*********************************************************************/
		@Override
		public int validPayeeAccountId(int payeeaccid) throws BankingException {
			Connection con;
			PreparedStatement pst = null;
			ResultSet rs = null;
			con = DbUtil.getConnection();
			
			try {
				pst = con.prepareStatement("SELECT count(account_id) FROM customeracc where account_id=?");
				pst.setInt(1, payeeaccid);
				rs = pst.executeQuery();
				rs.next();
				
				int result=rs.getInt(1);
				return result;
				
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					throw new BankingException(e.getMessage());
				}
			}
			
		}
		/*********************************************************************
		* Module Name :	 getBalanceById(int accountid)
		* Input Parameters : accountid
		* Return Type : int
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To retrieve the balance of the account holder
		*********************************************************************/
		@Override
		public int getBalanceById(int accountid) throws BankingException {
			Connection con;
			PreparedStatement pst = null;
			ResultSet rs = null;
			con = DbUtil.getConnection();
			
			try {
				pst = con.prepareStatement("SELECT account_balance FROM accountmaster where account_id=?");
				pst.setInt(1, accountid);
				rs = pst.executeQuery();
				rs.next();
				
				return rs.getInt(1);
				
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					throw new BankingException(e.getMessage());
				}
			}
			
		}
		/*********************************************************************
		* Module Name :	 updateBalance(int fromid, int toid, int tamount)
		* Input Parameters : fromid, toid,tamount
		* Return Type : int
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To check whether the balance of the account holder is updated or not
		*********************************************************************/
		@Override
		public int updateBalance(int fromid, int toid, int tamount) throws BankingException {
			Connection con;
			PreparedStatement pst = null;
			con = DbUtil.getConnection();
			
			try {
				pst = con.prepareStatement
						("UPDATE AccountMaster SET Account_Balance=Account_Balance-? WHERE Account_ID=?");
				pst.setInt(1, tamount);
				pst.setInt(2, fromid);
				int result1=pst.executeUpdate();
				
				pst = con.prepareStatement
						("UPDATE AccountMaster SET Account_Balance=Account_Balance+? WHERE Account_ID=?");
				pst.setInt(1, tamount);
				pst.setInt(2, toid);
				int result2=pst.executeUpdate();
				int result=0;
				if(result1==1 && result2==1){
					result=1;
				}
				return result;
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					throw new BankingException(e.getMessage());
				}
			}
		}
		/*********************************************************************
		* Module Name :	 updateFundTransfer(FundTransferDTO fund)
		* Input Parameters : fund
		* Return Type : int
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To check whether the FundTransfer table in database is updated or not
		*********************************************************************/
		@Override
		public int updateFundTransfer(FundTransferDTO fund) throws BankingException {
			Connection con;
			PreparedStatement pst = null;
			con = DbUtil.getConnection();
			
			try {
				pst = con.prepareStatement
						("INSERT INTO Fund_Transfer VALUES(Fund_Transfer_seq.nextval,?,?,sysdate,?)");
				pst.setInt(1, fund.getAccountID());
				pst.setInt(2, fund.getPayeeAccountId());
				pst.setInt(3, fund.getTransferAmount());
				int result=pst.executeUpdate();
				return result;
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					throw new BankingException(e.getMessage());
				}
			}
			
		}
		/*********************************************************************
		* Module Name :	updateTransaction(TransactionDTO tran)
		* Input Parameters :tran
		* Return Type : int
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To check whether the Transaction table in database is updated or not
		*********************************************************************/
		@Override
		public int updateTransaction(TransactionDTO tran) throws BankingException {
			Connection con;
			PreparedStatement pst = null;
			con = DbUtil.getConnection();
			
			try {
				pst = con.prepareStatement
						("INSERT INTO Transactions VALUES(Transactions_seq.nextval,?,sysdate,?,?,?)");
				pst.setString(1, tran.getTranDescription());
				pst.setString(2, tran.getTransactionType());
				pst.setInt(3, tran.getTranAmount());
				pst.setInt(4, tran.getAccountNumber());
				int result=pst.executeUpdate();
				return result;
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					throw new BankingException(e.getMessage());
				}
			}
		}
		/*********************************************************************
		* Module Name :	updatePassword(int userid, String password)
		* Input Parameters : userid, password
		* Return Type : int
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To check whether the password in database is updated or not
		*********************************************************************/
		@Override
		public int updatePassword(int userid, String password)
				throws BankingException {
			Connection con;
			PreparedStatement pst = null;
			con = DbUtil.getConnection();
			
			try {
				pst = con.prepareStatement
						("UPDATE user_table SET loginpassword=? WHERE User_ID=?");
				pst.setString(1, password);
				pst.setInt(2, userid);
				int result=pst.executeUpdate();
				return result;
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					throw new BankingException(e.getMessage());
				}
			}
		}
		/*********************************************************************
		* Module Name : updateAddress(int accid, String address)
		* Input Parameters : accid,address
		* Return Type : int
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To check whether the address in database is updated or not
		*********************************************************************/
		@Override
		public int updateAddress(int accid, String address) throws BankingException {
			Connection con;
			PreparedStatement pst = null;
			con = DbUtil.getConnection();
			
			try {
				pst = con.prepareStatement
						("UPDATE CustomerAcc SET Address=? WHERE Account_ID=?");
				pst.setString(1, address);
				pst.setInt(2, accid);
				int result=pst.executeUpdate();
				return result;
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					throw new BankingException(e.getMessage());
				}
			}
			
		}
	
		/*********************************************************************
		* Module Name : getTransactionDetailsByUserId(int accid1)
		* Input Parameters : accid1
		* Return Type : List<TransactionDTO> 
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To retrieve the transaction details
		*********************************************************************/
		@Override
		public List<TransactionDTO> getTransactionDetailsByUserId(int accid1)
				throws BankingException {
			
			Connection con;
			PreparedStatement pst = null;
			ResultSet rs = null;
			 List<TransactionDTO> list=new ArrayList<TransactionDTO>();
			con = DbUtil.getConnection();
			
			try {
				
				pst = con.prepareStatement("select * from(select * from transactions where account_id=? "
						+ "order by dateoftransaction desc) where rownum<=10");
				pst.setInt(1, accid1);
				rs  = pst.executeQuery();
				while(rs.next()){
					TransactionDTO tran=new TransactionDTO();	
					tran.setTransactionId(rs.getInt(1));
					tran.setTranDescription(rs.getString(2));
					tran.setDateOfTransaction(rs.getDate(3));
					tran.setTransactionType(rs.getString(4));
					tran.setTranAmount(rs.getInt(5));
					tran.setAccountNumber(rs.getInt(6));
						
					list.add(tran);
				
					}
					return list;	
				}
				 catch (SQLException e) {
				throw new BankingException(e.getMessage());
				}
				finally{
					try {
						con.close();
						pst.close();
						rs.close();
					} catch (SQLException e) {
						throw new BankingException(e.getMessage());
					}
					finally{
						try {
							con.close();
						} catch (SQLException e) {
							throw new BankingException(e.getMessage());
						}
					}
				}
	
		}
		/*********************************************************************
		* Module Name : getCustomerDetails(int account_id)
		* Input Parameters : account_id
		* Return Type : CustomerDTO
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To retrieve the customer details
		*********************************************************************/
		@Override
		public CustomerDTO getCustomerDetails(int account_id)
				throws BankingException {
			
			Connection con;
			PreparedStatement pst = null;
			ResultSet rs = null;
			CustomerDTO custObject = new CustomerDTO();
			
			con = DbUtil.getConnection();
			
			try {
				pst = con.prepareStatement("SELECT * FROM CustomerAcc where account_id=?");
				
				pst.setInt(1, account_id);
				
				rs  = pst.executeQuery();
				rs.next();
				custObject.setAccountId(rs.getInt(1));
				custObject.setCustomerName(rs.getString(2));
				custObject.setEmail(rs.getString(3));
				custObject.setAddress(rs.getString(4));
				custObject.setPancard(rs.getString(5));
				return custObject;
				
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}finally{
				try {
					con.close();
					pst.close();
					rs.close();
				} catch (SQLException e) {
					throw new BankingException(e.getMessage());
				}
				
			}
	
		}
		/*********************************************************************
		* Module Name :updateLockStatus(int account_id)
		* Input Parameters : account_id
		* Return Type : int
		* Author : Group5
		* Creation Date : 20-December-2017
		* Description : To check whether lock status is updated or not in database
		*********************************************************************/
		@Override
		public int updateLockStatus(int account_id) throws BankingException {
			Connection con;
			PreparedStatement pst = null;
			Integer result;
			con = DbUtil.getConnection();
			try {
				pst = con.prepareStatement("UPDATE User_Table SET lock_status='L' WHERE account_id=?");
				pst.setInt(1, account_id);
				result = pst.executeUpdate();
			} catch (SQLException e) {
				throw new BankingException(e.getMessage());
			}
			return result; 
		}
	
	
	}

package com.cg.obs.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.obs.exception.BankingException;

public class DbUtil {
	
	public static Connection getConnection() throws BankingException{
		InitialContext context=null;
		DataSource ds=null;
		try {
			context=new InitialContext();
			ds=(DataSource)context.lookup("java:/jdbc/OracleDS");
			return ds.getConnection();
			
		} catch (NamingException e) {
			throw new BankingException(e.getMessage());
		} catch (SQLException e) {
			throw new BankingException(e.getMessage());
		}
		
	}
}

package com.cg.obs.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import com.cg.obs.dao.BankingDAOImpl;
import com.cg.obs.exception.BankingException;

	public class BankingTest {
		BankingDAOImpl dao;
		@Before
	public void initialize(){
		dao = new BankingDAOImpl();
	}

		@Test
		public void testGetUserDetails() {
			try {
				assertNotNull(dao.getUserDetails(5000));
			} catch (BankingException e) {
			System.out.println(e.getMessage());
			}
		}
		@Test
		public void testGetPayeeDetails() {
		
			try {
				assertNotNull(dao.getPayeeDetails(1001));
			} catch (BankingException e) {
				System.out.println(e.getMessage());
			}
			
		}
		@Test
		public void testGetAccountDetailsByUserId() {
			try {
				assertNotNull(dao.getAccountDetailsByUserId(100));
			} catch (BankingException e) {
				System.out.println(e.getMessage());
			}
		}
	@Ignore
		@Test
		public void testInsertPayeeDetails() {
			fail("Not yet implemented");
		}

		@Test
		public void testValidPayeeAccountId() {
			try {
				
				assertEquals(1,dao.validPayeeAccountId(100));
			} catch (BankingException e) {
				System.out.println(e.getMessage());
			};
			
		}
	@Ignore
		@Test
		public void testGetBalanceById() {
			fail("Not yet implemented");
		}
	@Ignore
		@Test
		public void testUpdateBalance() {
			fail("Not yet implemented");
		}
	@Ignore
		@Test
		public void testUpdateFundTransfer() {
			fail("Not yet implemented");
		}
	@Ignore
		@Test
		public void testUpdateTransaction() {
			fail("Not yet implemented");
		}
		@Test
		public void testGetTransactionDetailsByUserId() {
			try {
				assertNotNull(dao.getTransactionDetailsByUserId(5000));
			} catch (BankingException e) {
				System.out.println(e.getMessage());
			}
			
		}
	@Ignore
		@Test
		public void testUpdatePassword() {
			fail("Not yet implemented");
		}
	@Ignore
		@Test
		public void testUpdateAddress() {
			fail("Not yet implemented");
		}
		@Test
		public void testGetCustomerDetails() {
		try {
			assertNotNull(dao.getCustomerDetails(5000));
		} catch (BankingException e) {
			System.out.println(e.getMessage());
		}
		
		}

	}



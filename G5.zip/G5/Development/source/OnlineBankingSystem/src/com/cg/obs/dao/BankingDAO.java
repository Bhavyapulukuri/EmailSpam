package com.cg.obs.dao;

import java.util.List;

import com.cg.obs.bean.CustomerDTO;
import com.cg.obs.bean.FundTransferDTO;
import com.cg.obs.bean.PayeeDTO;
import com.cg.obs.bean.TransactionDTO;
import com.cg.obs.bean.UserTableDTO;
import com.cg.obs.exception.BankingException;

public interface BankingDAO {

	public UserTableDTO getUserDetails(Integer userId) throws BankingException;

	public List<PayeeDTO> getPayeeDetails(int account_id)  throws BankingException; 
	
	public List<Integer> getAccountDetailsByUserId(int user_id)  throws BankingException;

	public int validPayeeAccountId(int payeeaccid) throws BankingException;
	
	public int insertPayeeDetails(PayeeDTO payee)throws BankingException;

	public int getBalanceById(int accountid)throws BankingException;
	
	public int updateBalance(int fromid,int toid, int tamount)throws BankingException;
	
	public int updateFundTransfer(FundTransferDTO fund)throws BankingException;
	
	public int updateTransaction(TransactionDTO tran)throws BankingException;
	
	public List<TransactionDTO> getTransactionDetailsByUserId(int accid1)  throws BankingException;

	int updatePassword(int userid, String password) throws BankingException;

	int updateAddress(int accid, String address) throws BankingException;

	CustomerDTO getCustomerDetails(int account_id) throws BankingException;

	public int updateLockStatus(int account_id) throws BankingException;
}

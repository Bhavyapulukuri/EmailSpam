package com.cg.obs.bean;

import java.util.Date;

public class TransactionDTO {

	private int transactionId;
	private String tranDescription;
	private Date dateOfTransaction;
	private String transactionType;
	private int tranAmount;
	private int accountNumber;
			public int getTransactionId() {
				return transactionId;
			}
			public void setTransactionId(int transactionId) {
				this.transactionId = transactionId;
			}
			public String getTranDescription() {
				return tranDescription;
			}
			public void setTranDescription(String tranDescription) {
				this.tranDescription = tranDescription;
			}
			public Date getDateOfTransaction() {
				return dateOfTransaction;
			}
			public void setDateOfTransaction(Date dateOfTransaction) {
				this.dateOfTransaction = dateOfTransaction;
			}
			public String getTransactionType() {
				return transactionType;
			}
			public void setTransactionType(String transactionType) {
				this.transactionType = transactionType;
			}
			public int getTranAmount() {
				return tranAmount;
			}
			public void setTranAmount(int tranAmount) {
				this.tranAmount = tranAmount;
			}
			public int getAccountNumber() {
				return accountNumber;
			}
			public void setAccountNumber(int accountNumber) {
				this.accountNumber = accountNumber;
			}
			
			@Override
			public String toString() {
				return "TransactionDTO [transactionId=" + transactionId
						+ ", tranDescription=" + tranDescription
						+ ", dateOfTransaction=" + dateOfTransaction
						+ ", transactionType=" + transactionType
						+ ", tranAmount=" + tranAmount + ", accountNumber="
						+ accountNumber + "]";
			}
		
	
}

package com.cg.obs.service;

import java.util.List;

import com.cg.obs.bean.CustomerDTO;
import com.cg.obs.bean.FundTransferDTO;
import com.cg.obs.bean.PayeeDTO;
import com.cg.obs.bean.TransactionDTO;
import com.cg.obs.bean.UserTableDTO;
import com.cg.obs.dao.BankingDAO;
import com.cg.obs.dao.BankingDAOImpl;
import com.cg.obs.exception.BankingException;

public class BankingServiceImpl implements BankingService {
	
	BankingDAO dao = new BankingDAOImpl();

	@Override
	public UserTableDTO getUserDetails(Integer userId) throws BankingException {
		
		return dao.getUserDetails(userId);
	}

	@Override
	public List<PayeeDTO> getPayeeDetails(int account_id) throws BankingException{
		return dao.getPayeeDetails(account_id);
	}

	@Override
	public List<Integer> getAccountDetailsByUserId(int user_id)
			throws BankingException {
		return dao.getAccountDetailsByUserId(user_id);
	}

	@Override
	public int insertPayeeDetails(PayeeDTO payee) throws BankingException {
		return dao.insertPayeeDetails(payee);
	}

	@Override
	public int validPayeeAccountId(int payeeaccid) throws BankingException {
		return dao.validPayeeAccountId(payeeaccid);
	}

	@Override
	public int getBalanceById(int accountid) throws BankingException {
		return dao.getBalanceById(accountid);
	}

	@Override
	public int updateBalance(int fromid, int toid, int tamount) throws BankingException {
		return dao.updateBalance(fromid, toid, tamount);
	}

	@Override
	public int updateFundTransfer(FundTransferDTO fund) throws BankingException {
		return dao.updateFundTransfer(fund);
	}

	@Override
	public int updateTransaction(TransactionDTO tran) throws BankingException {
		return dao.updateTransaction(tran);
	}

	@Override
	public List<TransactionDTO> getTransactionDetailsByUserId(int accid1)
			throws BankingException {
		return dao.getTransactionDetailsByUserId(accid1);
	}

	@Override
	public int updatePassword(int userid, String password)
			throws BankingException {
		
		return dao.updatePassword(userid, password);
	}

	@Override
	public int updateAddress(int accid, String address) throws BankingException {
		
		return dao.updateAddress(accid, address);
	}

	@Override
	public CustomerDTO getCustomerDetails(int account_id)
			throws BankingException {
		
		return dao.getCustomerDetails(account_id);
	}

	@Override
	public int updateLockStatus(int account_id) throws BankingException {
		// TODO Auto-generated method stub
		return dao.updateLockStatus(account_id);
	}

}

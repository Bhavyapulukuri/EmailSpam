package com.cg.obs.bean;

public class AccountMasterDTO {

}

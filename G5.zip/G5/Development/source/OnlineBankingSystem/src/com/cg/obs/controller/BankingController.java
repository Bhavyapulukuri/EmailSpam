package com.cg.obs.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.obs.bean.CustomerDTO;
import com.cg.obs.bean.FundTransferDTO;
import com.cg.obs.bean.PayeeDTO;
import com.cg.obs.bean.TransactionDTO;
import com.cg.obs.bean.UserTableDTO;
import com.cg.obs.exception.BankingException;
import com.cg.obs.service.BankingService;
import com.cg.obs.service.BankingServiceImpl;


/*********************************************************************
* Class Name : BankingController
* Author : Group5
* Creation Date : 20-December-2017
* Description : This controls all the java server pages that client requests.
*********************************************************************/
@WebServlet("*.do")
public class BankingController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	static Integer attempt=0;
	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	}

	/*********************************************************************
	* Module Name :  doGet
	* Input Parameters : request,response
	* Return Type : void
	* Author : Group5
	* Creation Date : 20-December-2017
	* Description : It process the get requests  
	*********************************************************************/
	protected void doGet(HttpServletRequest request, HttpServletResponse response)  
			throws ServletException, IOException  {
		
		String urlPattern = request.getServletPath();
		System.out.println(urlPattern);
		HttpSession session = request.getSession();
		
		BankingService service = new BankingServiceImpl(); 
		
		UserTableDTO userObject = new UserTableDTO();
		
		RequestDispatcher rd = null;
		
		
		switch(urlPattern){

			case "/LoginPage.do":
				rd = request.getRequestDispatcher("Login/Login.jsp");
				rd.forward(request, response);
			break;
			case "/Forgetpass.do":
				rd = request.getRequestDispatcher("ForgetPassword/ForgetPassword.jsp");
				rd.forward(request, response);
			break;
			
			case "/Forgetpassword.do":
				int user_id=Integer.parseInt(request.getParameter("userid"));
				session.setAttribute("user_id",user_id);
			try {
				userObject = service.getUserDetails(user_id);
				String secret=request.getParameter("secret");
				String secret1=userObject.getSecret_question();
				if(secret.equals(secret1)){
					rd = request.getRequestDispatcher("Change Password/ChangePassword.jsp");
					rd.forward(request, response);
				}
				else
				{
					session.setAttribute("error","Entered incorrect answer!Try  Again!!");
					rd=request.getRequestDispatcher("/Success/Failure.jsp");						
					rd.forward(request, response);
					
					
				}
			} catch (BankingException e1) {
				session.setAttribute("error", e1.getMessage());
				response.sendRedirect("error.jsp");
			}
			break;
			
			case "/ChangeForgetpassword.do":
				
				String npassword1=request.getParameter("npassword");
				int user_id1=(int) session.getAttribute("user_id");
				try {
						int dataUpdated= service.updatePassword(user_id1, npassword1);
						if(dataUpdated==1){
							rd = request.getRequestDispatcher("Login/Login.jsp");
							rd.forward(request, response);
						}
						else
						{
							session.setAttribute("error","Entered incorrect user Id!Try  Again!!");
							rd=request.getRequestDispatcher("/Success/Failure.jsp");						
							rd.forward(request, response);
							
							
						}
				}catch (BankingException e) {
						session.setAttribute("error", e.getMessage());
						response.sendRedirect("error.jsp");
					}
					
				
			break;
			
		case "/Home.do":
			rd = request.getRequestDispatcher("/Home/Home.jsp");
			rd.forward(request, response);

			break;
			
			case "/HomePage.do":
				
				
					try{
						Integer userId = Integer.parseInt(request.getParameter("userid"));
						session.setAttribute("userId", userId);
						String password = request.getParameter("password");
						
							
							userObject = service.getUserDetails(userId);
							session.setAttribute("userObject", userObject);
							session.setAttribute("accid", userObject.getAccount_id());
							session.setAttribute("utpassword", userObject.getTransaction_password());
							session.setAttribute("upassword",userObject.getLogin_password());
							
						if(userObject.getLock_status().equalsIgnoreCase("u")){
							
							if(userId.equals(userObject.getUser_id()) && password.equals(userObject.getLogin_password())){					
									
								int balance = service.getBalanceById(userObject.getAccount_id());
								
									session.setAttribute("homeBalance", balance);
									
									rd = request.getRequestDispatcher("/Home/Home.jsp");
									rd.forward(request, response);
			
							}else{
								
								
								attempt++;
								
								if(attempt>=3){
									
									int status = service.updateLockStatus(userObject.getAccount_id());
									if(status==1){
										attempt=0;
										session.setAttribute("error", "Your account is blocked ");		
										request.getRequestDispatcher("/Error/Error.jsp").forward(request, response);
									}

								}else{
									String message = "User Id or Password is Invalid";
									
									session.setAttribute("message", message);
									rd = request.getRequestDispatcher("Login/Login.jsp");
									rd.forward(request, response);
									
								}
								
								}
							
							}else{
								session.setAttribute("error", "This account is blocked ");		
								rd = request.getRequestDispatcher("/Error/Error.jsp");
								rd.forward(request, response);
								
								}
						
					}	catch (BankingException e) {
						
						session.setAttribute("error", e.getMessage());
						rd = request.getRequestDispatcher("Error/Error.jsp");
						rd.forward(request, response);
						
					}					
		
				break;
				
			case "/FundTransferPage.do":
				
				List<PayeeDTO> payeeList = new ArrayList<PayeeDTO>();
				List<Integer> acclist= new ArrayList<Integer>();
			try {
				
				int uId1=(int) session.getAttribute("accid");
				
				payeeList = service.getPayeeDetails(uId1);
				
				int uId=(int) session.getAttribute("userId");
				acclist=service.getAccountDetailsByUserId(uId);
				
				session.setAttribute("payeeList", payeeList);
				session.setAttribute("acclist", acclist);
				rd = request.getRequestDispatcher("/FundsTransfer/FundsTransfer.jsp");
				rd.forward(request, response);
			
				
			} catch (BankingException e) {
				session.setAttribute("error", e.getMessage());
				rd = request.getRequestDispatcher("Error/Error.jsp");
				rd.forward(request, response);
			}
			break;	
			case "/addPayee.do":
				session.getAttribute("accid");
				rd = request.getRequestDispatcher("/RegisterPayee/RegisterPayee.jsp");
				rd.forward(request, response);
			break;
			case "/Urn.do":
				
				int payeeaccid=Integer.parseInt(request.getParameter("payeeaccid"));
				String nickname=request.getParameter("nickname");
				session.setAttribute("payeeaccid", payeeaccid);
				session.setAttribute("nickname", nickname);
				rd=request.getRequestDispatcher("/URN/URN.jsp");
				rd.forward(request, response);
			break;
			case "/validateurn.do":
				String urn1="abc345";
				String urn=request.getParameter("urn");
				if(urn.equals(urn1)){
					int useraccid= (int) session.getAttribute("accid");
					payeeaccid=(int) session.getAttribute("payeeaccid");
					nickname=(String) session.getAttribute("nickname");
					
					PayeeDTO payee=new PayeeDTO();
					payee.setAccount_id(useraccid);
					payee.setPayeeAccount_id(payeeaccid);
					payee.setNick_name(nickname);
		
					try {
						int flag=service.validPayeeAccountId(payeeaccid);
							if(flag>0){
								int result=service.insertPayeeDetails(payee);
								String message = "Payee Added Successfully..!";
								session.setAttribute("message", message);
								rd=request.getRequestDispatcher("/PayeeAdded/PayeeAdded.jsp");
								rd.forward(request, response);
							}else{
								
								session.setAttribute("error","Sorry!Payee not added!Try  Again!!");
								rd=request.getRequestDispatcher("/Success/Failure.jsp");						
								rd.forward(request, response);
							}
								
						} 
					catch (BankingException e) {
						session.setAttribute("error", e.getMessage());
						rd = request.getRequestDispatcher("Error/Error.jsp");
						rd.forward(request, response);
						}
				}
			break;
			case "/payment.do":
				int myAccount=Integer.parseInt(request.getParameter("myAccount"));
				int toAccount=Integer.parseInt(request.getParameter("toAccount"));
				session.setAttribute("myAccount", myAccount);
				session.setAttribute("toAccount", toAccount);
				rd=request.getRequestDispatcher("/MakePayment/MakePayment.jsp");
				rd.forward(request, response);
			break;
			
			
			case "/ValidateTransaction.do":
				
				int tamount= Integer.parseInt(request.getParameter("tamount"));
				String tpassword=request.getParameter("tpassword");
				
				int myAccount1=(int)session.getAttribute("myAccount");
				int toAccount1=(int)session.getAttribute("toAccount");
				System.out.println("a");
				String utpassword =   (String) session.getAttribute("utpassword");
				int balance;
			try {
				balance = service.getBalanceById(myAccount1);
				if(tpassword.equals(utpassword) && (tamount<=balance)){
					int result=service.updateBalance(myAccount1, toAccount1, tamount);
					if(result==1){
						FundTransferDTO fund =new FundTransferDTO();
						fund.setAccountID(myAccount1);
						fund.setPayeeAccountId(toAccount1);
						fund.setTransferAmount(tamount);
						int result1=service.updateFundTransfer(fund);
						System.out.println("b");
						TransactionDTO tran=new TransactionDTO();
						tran.setTranDescription("Amount was Debited");
						tran.setTransactionType("D");
						tran.setTranAmount(tamount);
						tran.setAccountNumber(myAccount1);
						int result2=service.updateTransaction(tran);
						System.out.println("c");
						TransactionDTO tran1=new TransactionDTO();
						tran1.setTranDescription("Amount was Credited");
						tran1.setTransactionType("C");
						tran1.setTranAmount(tamount);
						tran1.setAccountNumber(toAccount1);
						System.out.println("d");
						int result3=service.updateTransaction(tran1);
						
						rd=request.getRequestDispatcher("/Success/Success.jsp");
						rd.forward(request, response);
					}
					else{
						session.setAttribute("error","Update Failed!Try  Again!!");
						rd=request.getRequestDispatcher("/Success/Failure.jsp");						
						rd.forward(request, response);
						
						
					}
					
				}else{
					
					session.setAttribute("error","Transaction Failed!!Try Again!!");
					rd = request.getRequestDispatcher("/Success/Failure.jsp");
					rd.forward(request, response);
				}
					
			} catch (BankingException e) {
				
				session.setAttribute("error", e.getMessage());
				rd = request.getRequestDispatcher("Error/Error.jsp");
				rd.forward(request, response);
			}
			break;
			case "/MiniStatement.do":
				
			try {
				 acclist= new ArrayList<Integer>();
				int uId=(int) session.getAttribute("userId");
				acclist=service.getAccountDetailsByUserId(uId);
				request.setAttribute("acclist",acclist);
				rd=request.getRequestDispatcher("/MiniStatement/GetMiniStatement.jsp");
				rd.forward(request, response);
				
			}
			catch (BankingException e) {
				session.setAttribute("error", e.getMessage());
				rd = request.getRequestDispatcher("Error/Error.jsp");
				rd.forward(request, response);
			}
			break;	
			case "/Mini.do":
				
			try {
				int accid1=Integer.parseInt(request.getParameter("myAccount1"));
				
				 List<TransactionDTO> list=new ArrayList<TransactionDTO>();
				list=service.getTransactionDetailsByUserId(accid1);
				request.setAttribute("list",list);
				rd=request.getRequestDispatcher("/MiniStatement/Mini.jsp");
				rd.forward(request, response);
				
			} catch (BankingException e) {
				session.setAttribute("error", e.getMessage());
				rd = request.getRequestDispatcher("Error/Error.jsp");
				rd.forward(request, response);
			}
			break;	
			
			case "/Changepass.do":
				rd=request.getRequestDispatcher("/HChangePassword/HChangePassword.jsp");
				rd.forward(request, response);
			break;
			
			case "/Changepassword.do":
				String cpassword=request.getParameter("cpassword");
				String npassword=request.getParameter("npassword");
				int userid=(int) session.getAttribute("userId");
				String upassword=(String) session.getAttribute("upassword");
				if(cpassword.equals(upassword) && !(cpassword.equals(npassword))){
					
					try {
						int dataUpdated= service.updatePassword(userid, npassword);
						if(dataUpdated==1){	
							rd = request.getRequestDispatcher("Login/Login.jsp");
							rd.forward(request, response);
						}
						else{
							String message = "Try  Again!!";
							session.setAttribute("message", message);
							rd=request.getRequestDispatcher("/PayeeAdded/PayeeAdded.jsp");						
							rd.forward(request, response);
					
						}
					} catch (BankingException e) {
						session.setAttribute("error", e.getMessage());
						rd = request.getRequestDispatcher("Error/Error.jsp");
						rd.forward(request, response);
					}
					
				}
				else{
					
					session.setAttribute("error","Entered incorrect Current Password!Try  Again!!");
					rd=request.getRequestDispatcher("/Success/Failure.jsp");						
					rd.forward(request, response);
					
				}
			break;
			
			case "/Changeaddress.do":
				int accid=(int) session.getAttribute("accid");
				
				CustomerDTO custObject = new CustomerDTO();
			try {
				custObject = service.getCustomerDetails(accid);
				session.setAttribute("address", custObject.getAddress());
				
				rd = request.getRequestDispatcher("/ChangeAddress/ChangeAddress.jsp");
				rd.forward(request, response);
				
			} catch (BankingException e) {
				session.setAttribute("error", e.getMessage());
				rd = request.getRequestDispatcher("Error/Error.jsp");
				rd.forward(request, response);
				
			}
			break;
			
			case "/Changeaddr.do":
				
				try {
					String address=request.getParameter("address");
					int accid1=(int) session.getAttribute("accid");
					int dataUpdated = service.updateAddress(accid1, address);
					if(dataUpdated==1){
						String message = "Address Changed Successfully..!";
						session.setAttribute("message", message);
						rd=request.getRequestDispatcher("/PayeeAdded/PayeeAdded.jsp");						
						rd.forward(request, response);
						
					}else{
						String message = "Try  Again!!";
						session.setAttribute("message", message);
						rd=request.getRequestDispatcher("/PayeeAdded/PayeeAdded.jsp");						
						rd.forward(request, response);
				
					}
					
				} catch (BankingException e) {
					session.setAttribute("error", e.getMessage());
					rd = request.getRequestDispatcher("Error/Error.jsp");
					rd.forward(request, response);
					
				}
					
			break;
			case "/aboutUs.do":
				
				rd = request.getRequestDispatcher("/AboutUs/AboutUs.jsp");
				rd.forward(request, response);
				break;
			case "/contactUs.do":
				rd = request.getRequestDispatcher("/ContactUs/ContactUs.jsp");
				rd.forward(request, response);
				break;
			
			case "/logout.do":
				request.getSession(false);
				
		        session.invalidate();
		        rd = request.getRequestDispatcher("Login/Login.jsp");
				rd.forward(request, response);
		        break;
		}
			
	}

	/*********************************************************************
	* Module Name : doPost
	* Input Parameters : request,response
	* Return Type : void
	* Author : Group5
	* Creation Date : 20-December-2017
	* Description : It calls the get method 
	*********************************************************************/
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}

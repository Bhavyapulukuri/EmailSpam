package com.cg.obs.bean;

import java.util.Date;

public class FundTransferDTO {

	private int fundTransferId;
	private int accountID ;
	private int payeeAccountId;
	private Date dateOfTransfer;
	private int transferAmount;
	
			public int getFundTransferId() {
				return fundTransferId;
			}
			public void setFundTransferId(int fundTransferId) {
				this.fundTransferId = fundTransferId;
			}
			public int getAccountID() {
				return accountID;
			}
			public void setAccountID(int accountID) {
				this.accountID = accountID;
			}
			public int getPayeeAccountId() {
				return payeeAccountId;
			}
			public void setPayeeAccountId(int payeeAccountId) {
				this.payeeAccountId = payeeAccountId;
			}
			public Date getDateOfTransfer() {
				return dateOfTransfer;
			}
			public void setDateOfTransfer(Date dateOfTransfer) {
				this.dateOfTransfer = dateOfTransfer;
			}
			public int getTransferAmount() {
				return transferAmount;
			}
			public void setTransferAmount(int transferAmount) {
				this.transferAmount = transferAmount;
			}
			
			@Override
			public String toString() {
				return "FundTransferDTO [fundTransferId=" + fundTransferId
						+ ", accountID=" + accountID + ", payeeAccountId="
						+ payeeAccountId + ", dateOfTransfer=" + dateOfTransfer
						+ ", transferAmount=" + transferAmount + "]";
			}
		
			
	
}
